import { NextPage } from 'next'
import { useState } from 'react'

import Button from '@/components/ui/button/Button'

import { axiosClassic } from '@/utils/api/api.interceptor'

import { saveToStorage } from '@/services/auth/auth.helper'

const LoginPage: NextPage = () => {
	const [email, setEmail] = useState('')
	const [password, setPassword] = useState('')

	console.log(email, password)

	const clickHandler = async () => {
		const req = await axiosClassic({
			url: '/auth/login',
			method: 'POST',
			data: JSON.stringify({
				email,
				password
			})
		})

		saveToStorage(req.data)
	}

	return (
		<form className='flex flex-col'>
			<label htmlFor=''>Email</label>
			<input
				onChange={e => setEmail(e.target.value)}
				className='py-5'
				type='text'
				placeholder='email there'
			/>

			<label htmlFor=''>Password</label>
			<input
				onChange={e => setPassword(e.target.value)}
				className='py-5'
				type='text'
				placeholder='Your pass there'
			/>

			<Button type='button' onClick={() => clickHandler()}>
				Login
			</Button>
		</form>
	)
}

export default LoginPage
