export interface IHeading {
	heading: string
	description?: string
}
