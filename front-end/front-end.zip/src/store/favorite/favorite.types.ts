import { IProductItem } from '@/types/product.interface'

export interface IFavoriteInitialState {
	items: IProductItem[]
}
