export default interface IMeta {
	title: string
	description?: string
	image?: string
}
