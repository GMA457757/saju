export const siteName = 'DreamProject'
export const titleMerge = (title: string) => `${title} | ${siteName}`
